import json
import os
import logging
from datetime import datetime
from elasticsearch import Elasticsearch
import boto3
from collections import defaultdict

# Set up logging
logging.basicConfig(level=logging.INFO,format='%(levelname)s: %(asctime)s: %(message)s')

# Set up Parameters
log_server = "https://"+os.environ.get('SERVER')
esport = int(os.environ.get('PORT'))
esuser = os.environ.get('ESUSER')
espassword = os.environ.get('ESPASSWORD')
source = os.environ.get('SOURCE')


# Creating Metadata for your logs
metadata = {
    'metadata': {
        'log_type': 'non-sys',
        'event_source': source
    }
}


# Logging Lambda Starts here
def lambda_handler(event, context):
    # Check prerequisites
    if log_server == '':
        raise Exception(
                'Please enter your log server info in Environment variablre before starting this lambda function')

    try:
        event = json.loads(event['Records'][0]['Sns']['Message'])
        logging.info('Invoking EC2-StatusHealth SNSsource %s region %s' % (event['AlarmName'], event['Region']))
        log = combine_logs(event) 
        send_logs(log)
    except Exception as e:
        raise e


# Format meta data + main log
def combine_logs(log_entry):
    combinedlog = append_metadata(log_entry, metadata)
    finallog = json.dumps(combinedlog)
    return finallog


# Append meta to main log entry
def append_metadata(a, b, path=None):
    if path is None: path = []
    for key in b:
        if key in a:
            if isinstance(a[key], dict) and isinstance(b[key], dict):
                append_metadata(a[key], b[key], path + [str(key)])
            elif a[key] == b[key]:
                pass
            else:
                raise Exception(
                        'Conflict while merging metadatas and the log entry at %s' % '.'.join(path + [str(key)]))
        else:
            a[key] = b[key]
    return a

# Send data to OpenSearchService Server
def send_logs(postdata):
    try:
        print (log_server, esuser, espassword, esport, source)
        logging.info(f'Sending: {postdata}')
        es = Elasticsearch(
            [log_server],
            http_auth=(esuser, espassword),
            scheme="https",
            port=esport
        )   

        res = es.index(index="ec2system-index", body=postdata)
        logging.info(f'Sent successfully')

        
        es.indices.refresh(index="ec2system-index")
        
        res = es.search(index="ec2system-index", body={"query": {"match_all": {}}})
        print("Got %d Hits:" % res['hits']['total']['value'])
    except Exception as e:
        raise e("Failing to send data to Elastic Search")